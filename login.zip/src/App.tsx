import React from 'react';
import Login from './components/Login';

const App: React.FC = () => {
  return (
    <Login />
  );
}

export default App;
